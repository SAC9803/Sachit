import React from 'react';
import { Headphones, Star, Battery, Wifi, Volume2 } from 'lucide-react';

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType, title: string, description: string }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
      <Icon className="w-8 h-8 text-indigo-600 mb-4" />
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="lg:w-1/2">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Experience Pure Sound
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Immerse yourself in crystal-clear audio with our premium wireless headphones.
              Designed for comfort, engineered for excellence.
            </p>
            <button className="bg-indigo-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-indigo-700 transition-colors">
              Shop Now
            </button>
          </div>
          <div className="lg:w-1/2">
            <img
              src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80"
              alt="Premium Headphones"
              className="rounded-2xl shadow-2xl w-full"
            />
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Our Headphones?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              icon={Battery}
              title="40h Battery Life"
              description="Long-lasting battery that keeps up with your lifestyle"
            />
            <FeatureCard
              icon={Wifi}
              title="Wireless Freedom"
              description="Bluetooth 5.0 for seamless connectivity"
            />
            <FeatureCard
              icon={Volume2}
              title="Active Noise Cancelling"
              description="Immerse yourself in pure sound without distractions"
            />
            <FeatureCard
              icon={Star}
              title="Premium Quality"
              description="Built with premium materials for lasting comfort"
            />
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="bg-indigo-600 rounded-2xl p-8 lg:p-12 text-center text-white">
          <Headphones className="w-16 h-16 mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Ready to Experience Amazing Sound?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who have already elevated their audio experience.
          </p>
          <button className="bg-white text-indigo-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors">
            Browse Collection
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;